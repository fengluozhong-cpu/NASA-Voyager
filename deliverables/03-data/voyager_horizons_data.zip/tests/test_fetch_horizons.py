"""Offline checks for scientific parsing, failure handling and safe writes."""
import contextlib
import io
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

import requests
import fetch_horizons as fh


def vector_text(start='2000-Jan-01 12:00:00.0000', jd=2451545.0):
    return '\nheader\n$$SOE\n' + (
        f'{jd}, A.D. {start}, 3, 4, 0, 0.03, 0.04, 0.12, {5/fh.C_KMS:.16g}, 5, 0.05,\n'
    ) + '$$EOE\nfooter\n'


def response(status, payload, headers=None):
    r = requests.Response()
    r.status_code = status
    r._content = json.dumps(payload).encode()
    r.headers.update(headers or {})
    return r


class ParseTests(unittest.TestCase):
    def test_units_and_derived_quantities(self):
        df = fh.parse_vectors(vector_text())
        self.assertEqual(list(df.columns), fh.VECTOR_COLUMNS)
        row = df.iloc[0]
        self.assertEqual(row.date_iso, '2000-01-01T12:00:00.000000')
        self.assertAlmostEqual(row.r_au, 5 / fh.AU_KM)
        self.assertAlmostEqual(row.v_kms, .13)
        self.assertAlmostEqual(row.speed_au_per_yr, .13*fh.YEAR_S/fh.AU_KM)
        self.assertAlmostEqual(row.light_days, 5/fh.C_KMS/86400)
        self.assertEqual(row.lat_deg, 0)

    def test_fortran_notation(self):
        df = fh.parse_vectors(vector_text().replace(', 3,', ', 3D0,'))
        self.assertEqual(df.x_km.iloc[0], 3)

    def test_bad_columns_do_not_silently_drop_rows(self):
        with self.assertRaisesRegex(ValueError, '11'):
            fh.parse_vectors(vector_text().replace(', 0.05,', ','))

    def test_nan_rejected(self):
        with self.assertRaisesRegex(ValueError, '非有限'):
            fh.parse_vectors(vector_text().replace(', 3,', ', NaN,'))

    def test_range_or_light_time_column_shift_rejected(self):
        with self.assertRaisesRegex(ValueError, 'RG'):
            fh.parse_vectors(vector_text().replace(', 5, 0.05,', ', 6, 0.05,'))
        with self.assertRaisesRegex(ValueError, 'LT'):
            fh.parse_vectors(vector_text().replace(f'{5/fh.C_KMS:.16g}', '0.1'))

    def test_empty_block_and_duplicate_epochs_rejected(self):
        with self.assertRaisesRegex(ValueError, '空'):
            fh.parse_vectors('$$SOE\n\n$$EOE')
        text = vector_text()
        line = text.split('$$SOE\n')[1].split('$$EOE')[0]
        with self.assertRaisesRegex(ValueError, '时间戳'):
            fh.parse_vectors(text.replace('$$EOE', line+'$$EOE'))

    def test_jd_calendar_disagreement_rejected(self):
        with self.assertRaisesRegex(ValueError, 'calendar_date'):
            fh.parse_vectors(vector_text(jd=2451546))

    def test_missing_grid_rows_rejected(self):
        df = fh.parse_vectors(vector_text())
        with self.assertRaisesRegex(ValueError, '覆盖'):
            fh.validate_grid(df, '2000-01-01T12:00:00', '2000-01-03T12:00:00', '1d')

    def test_clip_preserves_midnight_grid(self):
        error = 'No ephemeris prior to A.D. 1977-SEP-05 13:59:24.3830 TDB'
        self.assertEqual(fh.clipped_bounds(error, '1977-09-01', '2026-11-13', '1d'),
                         ('1977-09-06T00:00:00', '2026-11-13T00:00:00'))
        self.assertIsNone(fh.clipped_bounds('Unknown target', '1977-09-01', '2026-11-13', '1d'))

    def test_timezone_rejected(self):
        with self.assertRaises(ValueError):
            fh.parse_time('2026-11-13T00:00:00Z')


class ClientTests(unittest.TestCase):
    def test_429_honors_retry_after_and_recovers(self):
        client = fh.HorizonsClient()
        client.session.get = Mock(side_effect=[response(429, {'error':'rate limited'}, {'Retry-After':'4'}),
                                               response(200, {'result':vector_text()})])
        records=[]
        with patch.object(fh.time, 'sleep') as sleep, contextlib.redirect_stderr(io.StringIO()):
            text, _, error = client.request({'COMMAND': "'-31'"}, records)
        self.assertIn('$$SOE', text)
        self.assertIsNone(error)
        self.assertEqual(client.session.get.call_count, 2)
        self.assertIn(unittest.mock.call(4.0), sleep.call_args_list)
        self.assertEqual([r['http_status'] for r in records], [429,200])

    def test_5xx_stops_after_five_retries(self):
        client=fh.HorizonsClient()
        client.session.get=Mock(return_value=response(503, {'error':'temporary'}))
        with patch.object(fh.time, 'sleep'), contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(requests.HTTPError):
                client.request({}, [])
        self.assertEqual(client.session.get.call_count, 6)

    def test_missing_soe_prints_server_text(self):
        client=fh.HorizonsClient()
        client.session.get=Mock(return_value=response(200, {'error':'No ephemeris', 'result':'server explanation'}))
        stderr=io.StringIO()
        with contextlib.redirect_stderr(stderr):
            text, payload, raw = client.request({}, [])
        self.assertIsNone(text)
        self.assertEqual(raw, 'server explanation')
        self.assertIn('server explanation', stderr.getvalue())


class OutputTests(unittest.TestCase):
    def test_existing_is_skipped_and_force_refreshes(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'vectors.csv'
            fh.parse_vectors(vector_text()).to_csv(path,index=False)
            job=fh.Job('voyager1','@sun','2000-01-01T12:00:00','2000-01-01T13:00:00','2h',path)
            client=Mock()
            client.request.return_value=(vector_text(),{},None)
            with contextlib.redirect_stdout(io.StringIO()):
                entry=fh.run_job(job, client, False, None)
            client.request.assert_not_called()
            self.assertEqual(entry['last_action'],'skipped_existing')
            refreshed=fh.run_job(job,client,True,None)
            self.assertEqual(refreshed['rows'],1)
            self.assertEqual(refreshed['last_action'],'fetched')
            self.assertFalse(path.with_suffix('.csv.tmp').exists())
            client.request.assert_called_once()

    def test_failed_request_does_not_create_empty_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'vectors.csv'
            job=fh.Job('voyager1','@sun','2000-01-01','2000-01-02','1d',path)
            client=Mock()
            client.request.return_value=(None,{'error':'Unknown failure'},'No ephemeris')
            entry=fh.run_job(job,client,False,None)
            self.assertEqual(entry['status'],'failed')
            self.assertFalse(path.exists())

    def test_failed_force_preserves_existing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'vectors.csv'
            path.write_text('original contents')
            job=fh.Job('voyager1','@sun','2000-01-01','2000-01-02','1d',path)
            client=Mock()
            client.request.return_value=(None,{'error':'Unknown failure'},'No ephemeris')
            fh.run_job(job,client,True,None)
            self.assertEqual(path.read_text(),'original contents')

    def test_earth_schema_uses_399_only(self):
        with tempfile.TemporaryDirectory() as folder:
            for center,columns in [('@399',fh.EARTH_COLUMNS),('@0',fh.VECTOR_COLUMNS)]:
                path=Path(folder)/f'{center}.csv'
                job=fh.Job('voyager1',center,'2000-01-01T12:00:00','2000-01-01T13:00:00','2h',path)
                client=Mock()
                client.request.return_value=(vector_text(),{},None)
                fh.run_job(job,client,False,None)
                self.assertEqual(path.read_text().splitlines()[0].split(','),columns)


if __name__=='__main__':
    unittest.main()
