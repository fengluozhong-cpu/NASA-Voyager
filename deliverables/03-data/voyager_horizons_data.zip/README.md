# Voyager Horizons 轨迹数据

从 NASA/JPL Horizons API 获取 Voyager 1、Voyager 2 的状态向量，用 Python 清洗、计算派生量并写入 CSV。仅处理数据，不含网站或可视化。

## 安装与运行

Python 3.10+：

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python fetch_horizons.py
```

默认输出到 `data/`，包含两艘探测器的日心/地心日采样、最近一年日心小时采样、未来日心日采样及六个事件窗口；元数据写入 `data/meta.json`。已存在的 CSV 默认跳过；`--force` 才重新拉取并覆盖。文件完成后会打印行数、起止日期和 `r_au` 最小/最大值；地心文件不保留 `r_au`，因此该项不适用。

```bash
# 完整批处理到另一个目录
python fetch_horizons.py --out ./voyager_data

# 只处理 Voyager 1 的整套文件
python fetch_horizons.py --target voyager1

# 强制刷新整套数据
python fetch_horizons.py --force

# 单条自定义请求（必须选择一艘探测器，--out 指定 CSV）
python fetch_horizons.py --target voyager2 --center @sun \
  --start 1989-08-22 --stop 1989-08-28 --step 1h --out ./custom/neptune.csv

# 自定义地心距离
python fetch_horizons.py --target voyager1 --center @399 \
  --start 2026-11-12 --stop 2026-11-13 --step 1h --out ./custom/earth.csv
```

`--target` 支持 `voyager1`、`voyager2`、`both`。不指定自定义参数时，按所选目标批量生成文件。指定 `--center`、`--start`、`--stop` 或 `--step` 中任意一项即进入自定义模式，需要单一目标及 CSV 输出路径；未指定项默认使用 `@sun`、`1977-09-01`、`2026-11-13`、`1d`。以 `python fetch_horizons.py --help` 为准。

## API 参数的必要校正

- **地心是 `CENTER='@399'`**。`@0` 是太阳系质心，不能把它返回的距离标记为离地球距离。默认地心文件均使用 `@399`；自定义模式仍允许 `@0`，输出完整向量字段并在元数据中标记为太阳系质心。
- **11 列需要 `VEC_TABLE='3'`**。`VEC_TABLE='2'` 只有 JDTDB、日期及六个位置/速度分量，不含 LT/RG/RR。脚本使用表 3 获得要求的全部原始字段。
- 所有发送的 Horizons 参数值均用单引号包裹；不发送 REST 层 `format` 参数，使用默认 JSON。`format='json'` 会被 API 拒绝，因为这一 REST 参数不接受带引号的值。
- Voyager 1 在 `1977-09-01` 尚无可用星历。当前服务器给出的最早时刻是 **1977-09-05 13:59:24.3830 TDB**。默认每日零点网格从 **1977-09-06 00:00:00 TDB** 开始，不填造发射前数据；元数据保留原始请求与实际范围。Voyager 2 从指定的 1977-09-01 开始，因此该文件不是从其 1977-08-20 发射时刻起的全部轨迹。

## 文件与范围

所有日期均为 **TDB**；范围两端在采样网格上时均包含。近一年以任务截止日为锚点，不随运行日期移动。未来文件从历史截止日的下一天开始，因此与历史日采样没有重复行。

| 文件（相对 `data/`） | 中心 | 范围（TDB） | 步长 |
| --- | --- | --- | --- |
| `voyager1_heliocentric_daily.csv` | 太阳 | 1977-09-06 至 2026-11-13 | 1d |
| `voyager2_heliocentric_daily.csv` | 太阳 | 1977-09-01 至 2026-11-13 | 1d |
| `voyager1_geocentric_daily.csv` | 地球中心 | 1977-09-06 至 2026-11-13 | 1d |
| `voyager2_geocentric_daily.csv` | 地球中心 | 1977-09-01 至 2026-11-13 | 1d |
| `voyager1_heliocentric_hourly_recent.csv` | 太阳 | 2025-11-13 至 2026-11-13 | 1h |
| `voyager2_heliocentric_hourly_recent.csv` | 太阳 | 2025-11-13 至 2026-11-13 | 1h |
| `voyager1_projected_to_2050.csv` | 太阳 | 2026-11-14 至 2050-01-01 | 1d |
| `voyager2_projected_to_2050.csv` | 太阳 | 2026-11-14 至 2050-01-01 | 1d |
| `events/v1_jupiter.csv` | 太阳 | 1979-03-02 至 1979-03-08 | 1h |
| `events/v1_saturn.csv` | 太阳 | 1980-11-09 至 1980-11-15 | 1h |
| `events/v2_saturn.csv` | 太阳 | 1981-08-22 至 1981-08-28 | 1h |
| `events/v2_uranus.csv` | 太阳 | 1986-01-21 至 1986-01-27 | 1h |
| `events/v2_neptune.csv` | 太阳 | 1989-08-22 至 1989-08-28 | 1h |
| `events/v1_heliopause.csv` | 太阳 | 2012-08-15 至 2012-09-04 | 1h |

事件时间窗以所给日期的 00:00 TDB 为中心，非精确最近接近时刻。事件文件保留日心完整向量及全部派生字段，便于分析速度变化；未另取行星中心向量。日球层顶穿越是空间环境事件，不是引力弹弓事件。

## CSV 字段

日心、事件及自定义非地心向量文件按以下顺序保存：

```text
jd_tdb,date_iso,x_km,y_km,z_km,vx_kms,vy_kms,vz_kms,lt_s,rg_km,rr_kms,r_au,v_kms,light_days,lat_deg,speed_au_per_yr
```

`speed_au_per_yr` 虽未出现在任务末尾的列清单中，但属于明确要求的派生量，因此也保留。除时间标签 `date_iso` 外均为数值列；不保存 Horizons 日历原文、表头或空行。

| 字段 | 含义与单位 |
| --- | --- |
| `jd_tdb` | TDB 儒略日，建议用于精确排序和跨文件连接 |
| `date_iso` | TDB 日历标签 `YYYY-MM-DDTHH:MM:SS[.小数]`，**不是 UTC**，不附加 `Z` 或时区偏移 |
| `x_km,y_km,z_km` | 相对所选中心的位置，km |
| `vx_kms,vy_kms,vz_kms` | 相对所选中心的速度，km/s |
| `lt_s` | 所选中心到目标的单程牛顿光行时，s |
| `rg_km` | 相对所选中心的距离，km |
| `rr_kms` | 相对所选中心的径向速度，km/s；正值表示远离 |
| `r_au` | 位置向量模长 / 149597870.7 km |
| `v_kms` | 速度向量模长，km/s；与径向速度 `rr_kms` 不同 |
| `light_days` | `lt_s / 86400` |
| `lat_deg` | `degrees(atan2(z, sqrt(x*x+y*y)))`，相对 J2000 黄道面的纬度，北为正 |
| `speed_au_per_yr` | `v_kms * 31557600 / 149597870.7`，AU/儒略年（365.25 日） |

这些派生量均在 Python 内计算，不另调 API。日心文件里的 `lt_s`、`rg_km`、`rr_kms` 是相对太阳的量，不能直接当成地球通信距离或通信时延。

地心 CSV 仅保留时间键及三个距离相关量：

```text
jd_tdb,date_iso,dist_from_earth_km,range_rate_kms,light_time_s
```

后三列分别由 Horizons 的 RG、RR、LT 重命名而来，单位 km、km/s、s。时间键保留以支持和日心文件按 `jd_tdb` 对齐。这里是地球**中心**，不是地面站，光行时也不是已应用相对论和传播修正的通信时延预报。

## 坐标系与时间口径

请求固定为 `EPHEM_TYPE='VECTORS'`、`OUT_UNITS='KM-S'`、`REF_SYSTEM='ICRF'`、`REF_PLANE='ECLIPTIC'`、`VEC_CORR='NONE'`、`TIME_TYPE='TDB'`。结果为 **J2000.0 黄道参考面下的几何状态向量**：X 轴沿 ICRF X 方向，XY 面采用 J2000 地球轨道平面，Z 轴指向该黄道面的北侧。Horizons 使用 IAU76 黄赤交角 84381.448 角秒将 ICRF 赤道参考系转至此面。

因此 `lat_deg` 明确是黄道纬度，不是赤纬；速度是相对于所选原点的向量导数，不是地球观测到的视运动。`VEC_CORR='NONE'` 未应用光行时、恒星像差等视位置修正。若网站需要 UTC，应使用专门的天文时间转换工具；不要仅对 `date_iso` 附加 `Z`。

## 来源、外推与分析限制

数据来源：[NASA/JPL Horizons API](https://ssd.jpl.nasa.gov/api/horizons.api)，[API 文档](https://ssd-api.jpl.nasa.gov/doc/horizons.html)，[Horizons 手册](https://ssd.jpl.nasa.gov/horizons/manual.html)。目标 ID：Voyager 1 `-31`、Voyager 2 `-32`。

**未来段为 Horizons 轨道模型外推，不是实际观测，精度会随时间和模型误差变化。** 本脚本不自行线性外推，也不把缺失星历插值成有效数据。`2026-11-13` 只是本数据集历史/未来文件的分界，不是 Horizons 观测/预测的真实分界。

2026-11-17 检查到的目标说明（2022-08-19 修订）表明：

- Voyager 1 在 1977-09-05 至 1981-01-01、Voyager 2 在 1977-08-20 至 1989-08-29 使用为匹配任务事件构造的拼接圆锥曲线，精度为近似任务设计级。
- 后续段采用 2022 年重拟合的解，基于截至 1992 年的跟踪数据，模型可延伸至 2100 年。因此部分名义上的“历史”日期也属于模型预测，不是同期实测轨迹。
- 一小时采样提高时间分辨率，不提高源轨道解的物理精度。飞掠窗口适合展示和定性研究；不宜直接当作高精度导航或引力弹弓反演数据。拼接模型可能在边界附近存在变化。

`meta.json` 保存来源、UTC 拉取时间、目标/中心、实际请求参数、请求与输出时间范围、行数、坐标与时间说明、外推声明和各文件状态。应将 CSV 与同次生成的元数据一起使用；重跑时跳过的文件保留原有来源记录，不应误认为刚从服务端刷新。

## 健壮性

每次请求之间至少间隔 0.3 秒。HTTP 429/5xx 与暂时性网络异常按指数退避重试，最多重试 5 次；429 的 `Retry-After` 会被考虑。先检查返回文本中的 `$$SOE` / `$$EOE`，无数据时打印服务端原文并记录失败，不生成空 CSV。只接受可解析且有限的数值，清洗后的数据按时间检查并写入结构化文件。

任务无法完整生成时，应查看终端错误与 `meta.json` 的状态；不要仅因输出目录存在就认定所有文件齐全。已有文件不会在默认重跑时被替换；确需刷新用 `--force`。

## 验证

离线边界与失败处理测试：

```bash
python -m unittest discover -s tests -v
```

随本次交付保存的 `data/source_notes/voyager1.txt`、`voyager2.txt` 为 NASA 目标说明原文（使用 `MAKE_EPHEM='NO'`、`OBJ_DATA='YES'` 另行核实），便于审阅轨道模型的来源与精度限制。主脚本的向量请求仍使用 `OBJ_DATA='NO'`；重新运行主脚本不会刷新这两份说明。
